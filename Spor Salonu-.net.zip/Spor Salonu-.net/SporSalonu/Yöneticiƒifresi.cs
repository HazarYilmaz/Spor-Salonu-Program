﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace SporSalonu
{
    public partial class frmyonetici_sifre : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        private string sifre;
        public frmyonetici_sifre()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        public bool Gonder(string konu, string icerik)
        {
            MailMessage ePosta = new MailMessage();
            ePosta.From = new MailAddress("hazarylmaz345@gmail.com");

            ePosta.To.Add(pgiris_sifre.Text);


            ePosta.Subject = konu;

            ePosta.Body = icerik;

            SmtpClient smtp = new SmtpClient();

            smtp.Credentials = new System.Net.NetworkCredential("hazarylmaz345@gmail.com", "hazarhazar34");

            smtp.Port = 587;
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            object userState = ePosta;
            bool kontrol = true;
            try
            {
                smtp.SendAsync(ePosta, (object)ePosta);
            }
            catch (SmtpException ex)
            {
                kontrol = false;
                System.Windows.Forms.MessageBox.Show(ex.Message, "Mail Gönderme Hatasi");
            }
            return kontrol;

        }
        private void frmyonetici_sifre_Load(object sender, EventArgs e)
        {
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button4, "İletişim");
            errorProvider1.BlinkRate = 400;
            errorProvider1.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;
            pgiris_tc.MaxLength = 11;
        }

        private void pgiris_tc_Enter(object sender, EventArgs e)
        {
            if (pgiris_tc.Text == "TC Kimlik")
            {
                pgiris_tc.Text = "";
                pgiris_tc.ForeColor = Color.White;

            }
        }

        private void pgiris_tc_Leave(object sender, EventArgs e)
        {
            if (pgiris_tc.Text == "")
            {
                pgiris_tc.Text = "TC Kimlik";
                pgiris_tc.ForeColor = Color.White;
            }
        }

        private void pgiris_sifre_Enter(object sender, EventArgs e)
        {
            if (pgiris_sifre.Text == "Email")
            {
                pgiris_sifre.Text = "";
                pgiris_sifre.ForeColor = Color.White;

            }
        }

        private void pgiris_sifre_Leave(object sender, EventArgs e)
        {
            if (pgiris_sifre.Text == "")
            {
                pgiris_sifre.Text = "Email";
                pgiris_sifre.ForeColor = Color.LightGray;
                pgiris_sifre.UseSystemPasswordChar = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
            }

            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
            }

            SqlCommand com = new SqlCommand("Select * from yoneticikayit where tckimlik='" + pgiris_tc.Text.ToString() +
                "'and email='" + pgiris_sifre.Text.ToString() + "'", baglanti);


            SqlDataReader oku = com.ExecuteReader();
            if (oku.Read())
            {


                sifre = oku["sifre"].ToString();

                MessageBox.Show("Girmiş Oldunuz Bilgiler Uyuşuyor Şifreniz Mail adresinize yollanıyor(Gereksiz kutusuna bakmayı unutmayın)");

                Gonder("Unutmuş Olduğunuz Şifreniz Ektededir", sifre);


                baglanti.Close();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Bilgileriniz Uyuşmadı");
                pgiris_tc.Clear();
                pgiris_tc.Text = "TC Kimlik";
                pgiris_sifre.Clear();
                pgiris_sifre.Text = "Email";
            }
            baglanti.Close();
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void pgiris_tc_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
