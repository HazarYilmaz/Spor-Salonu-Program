﻿namespace SporSalonu
{
    partial class frm_personelkayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_personelkayit));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnkapat = new System.Windows.Forms.Button();
            this.btnkücült = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.pkayit_adres = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pkayit_dogum = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.pkayit_maas = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pkayit_sifret = new System.Windows.Forms.TextBox();
            this.pkayit_sifre = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pkayit_mail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pkayit_tel = new System.Windows.Forms.MaskedTextBox();
            this.pkayit_cinsiyet = new System.Windows.Forms.ComboBox();
            this.pkayit_tc = new System.Windows.Forms.TextBox();
            this.pkayit_soyad = new System.Windows.Forms.TextBox();
            this.pkayit_ad = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.btnkapat);
            this.panel1.Controls.Add(this.btnkücült);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(624, 45);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.Image = global::SporSalonu.Properties.Resources.icons8_go_back_filled_25;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(516, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(34, 38);
            this.button5.TabIndex = 58;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(546, -2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(32, 40);
            this.button4.TabIndex = 54;
            this.button4.Text = "?";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnkapat
            // 
            this.btnkapat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnkapat.FlatAppearance.BorderSize = 0;
            this.btnkapat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkapat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnkapat.ForeColor = System.Drawing.Color.White;
            this.btnkapat.Location = new System.Drawing.Point(596, 3);
            this.btnkapat.Name = "btnkapat";
            this.btnkapat.Size = new System.Drawing.Size(28, 30);
            this.btnkapat.TabIndex = 4;
            this.btnkapat.Text = "X";
            this.btnkapat.UseVisualStyleBackColor = true;
            this.btnkapat.Click += new System.EventHandler(this.btnkapat_Click);
            // 
            // btnkücült
            // 
            this.btnkücült.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnkücült.FlatAppearance.BorderSize = 0;
            this.btnkücült.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkücült.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnkücült.ForeColor = System.Drawing.Color.White;
            this.btnkücült.Location = new System.Drawing.Point(572, 2);
            this.btnkücült.Name = "btnkücült";
            this.btnkücült.Size = new System.Drawing.Size(28, 30);
            this.btnkücült.TabIndex = 3;
            this.btnkücült.Text = "_";
            this.btnkücült.UseVisualStyleBackColor = true;
            this.btnkücült.Click += new System.EventHandler(this.btnkücült_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(237, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Personel Kayıt";
            this.label2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label2_MouseDown);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.pkayit_adres);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.pkayit_dogum);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.pkayit_maas);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.pkayit_sifret);
            this.groupBox1.Controls.Add(this.pkayit_sifre);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.pkayit_mail);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.pkayit_tel);
            this.groupBox1.Controls.Add(this.pkayit_cinsiyet);
            this.groupBox1.Controls.Add(this.pkayit_tc);
            this.groupBox1.Controls.Add(this.pkayit_soyad);
            this.groupBox1.Controls.Add(this.pkayit_ad);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(600, 300);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personel Bilgileri";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(74, 278);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 13);
            this.label13.TabIndex = 47;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SeaGreen;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(372, 229);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 40);
            this.button1.TabIndex = 12;
            this.button1.Text = "Kaydet";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Silver;
            this.label12.Location = new System.Drawing.Point(315, 97);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 18);
            this.label12.TabIndex = 46;
            this.label12.Text = "Adres";
            // 
            // pkayit_adres
            // 
            this.pkayit_adres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pkayit_adres.Location = new System.Drawing.Point(372, 97);
            this.pkayit_adres.MaxLength = 750;
            this.pkayit_adres.Name = "pkayit_adres";
            this.pkayit_adres.Size = new System.Drawing.Size(170, 96);
            this.pkayit_adres.TabIndex = 11;
            this.pkayit_adres.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.Silver;
            this.label11.Location = new System.Drawing.Point(315, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 18);
            this.label11.TabIndex = 44;
            this.label11.Text = "Doğum tarihi";
            // 
            // pkayit_dogum
            // 
            this.pkayit_dogum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_dogum.Location = new System.Drawing.Point(425, 65);
            this.pkayit_dogum.Name = "pkayit_dogum";
            this.pkayit_dogum.Size = new System.Drawing.Size(117, 21);
            this.pkayit_dogum.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.Silver;
            this.label10.Location = new System.Drawing.Point(315, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 18);
            this.label10.TabIndex = 42;
            this.label10.Text = "Maaş";
            // 
            // pkayit_maas
            // 
            this.pkayit_maas.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.pkayit_maas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_maas.Location = new System.Drawing.Point(425, 29);
            this.pkayit_maas.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.pkayit_maas.MaxLength = 5;
            this.pkayit_maas.Multiline = true;
            this.pkayit_maas.Name = "pkayit_maas";
            this.pkayit_maas.Size = new System.Drawing.Size(117, 22);
            this.pkayit_maas.TabIndex = 9;
            this.pkayit_maas.TextChanged += new System.EventHandler(this.pkayit_maas_TextChanged);
            this.pkayit_maas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pkayit_maas_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.Silver;
            this.label9.Location = new System.Drawing.Point(6, 248);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 18);
            this.label9.TabIndex = 40;
            this.label9.Text = "Şifre(T)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.Silver;
            this.label8.Location = new System.Drawing.Point(6, 216);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 18);
            this.label8.TabIndex = 39;
            this.label8.Text = "Şifre";
            // 
            // pkayit_sifret
            // 
            this.pkayit_sifret.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.pkayit_sifret.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_sifret.Location = new System.Drawing.Point(90, 247);
            this.pkayit_sifret.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.pkayit_sifret.MaxLength = 25;
            this.pkayit_sifret.Multiline = true;
            this.pkayit_sifret.Name = "pkayit_sifret";
            this.pkayit_sifret.PasswordChar = '*';
            this.pkayit_sifret.Size = new System.Drawing.Size(117, 22);
            this.pkayit_sifret.TabIndex = 8;
            // 
            // pkayit_sifre
            // 
            this.pkayit_sifre.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.pkayit_sifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_sifre.Location = new System.Drawing.Point(90, 215);
            this.pkayit_sifre.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.pkayit_sifre.MaxLength = 25;
            this.pkayit_sifre.Multiline = true;
            this.pkayit_sifre.Name = "pkayit_sifre";
            this.pkayit_sifre.PasswordChar = '*';
            this.pkayit_sifre.Size = new System.Drawing.Size(117, 22);
            this.pkayit_sifre.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.Silver;
            this.label7.Location = new System.Drawing.Point(6, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 18);
            this.label7.TabIndex = 36;
            this.label7.Text = "E-mail";
            // 
            // pkayit_mail
            // 
            this.pkayit_mail.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.pkayit_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_mail.Location = new System.Drawing.Point(90, 183);
            this.pkayit_mail.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.pkayit_mail.MaxLength = 75;
            this.pkayit_mail.Multiline = true;
            this.pkayit_mail.Name = "pkayit_mail";
            this.pkayit_mail.Size = new System.Drawing.Size(117, 22);
            this.pkayit_mail.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.Silver;
            this.label6.Location = new System.Drawing.Point(6, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 18);
            this.label6.TabIndex = 34;
            this.label6.Text = "Cinsiyet";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Silver;
            this.label5.Location = new System.Drawing.Point(6, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 18);
            this.label5.TabIndex = 33;
            this.label5.Text = "Telefon";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Silver;
            this.label4.Location = new System.Drawing.Point(6, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 18);
            this.label4.TabIndex = 32;
            this.label4.Text = "Tc Kimlik";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Silver;
            this.label3.Location = new System.Drawing.Point(6, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 18);
            this.label3.TabIndex = 31;
            this.label3.Text = "Soyad";
            // 
            // pkayit_tel
            // 
            this.pkayit_tel.Location = new System.Drawing.Point(90, 123);
            this.pkayit_tel.Mask = "00000000000";
            this.pkayit_tel.Name = "pkayit_tel";
            this.pkayit_tel.Size = new System.Drawing.Size(117, 20);
            this.pkayit_tel.TabIndex = 4;
            this.pkayit_tel.ValidatingType = typeof(int);
            this.pkayit_tel.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.pkayit_tel_MaskInputRejected);
            this.pkayit_tel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pkayit_tel_KeyPress);
            // 
            // pkayit_cinsiyet
            // 
            this.pkayit_cinsiyet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pkayit_cinsiyet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_cinsiyet.FormattingEnabled = true;
            this.pkayit_cinsiyet.Items.AddRange(new object[] {
            "Kadın",
            "Erkek"});
            this.pkayit_cinsiyet.Location = new System.Drawing.Point(90, 154);
            this.pkayit_cinsiyet.Name = "pkayit_cinsiyet";
            this.pkayit_cinsiyet.Size = new System.Drawing.Size(117, 21);
            this.pkayit_cinsiyet.TabIndex = 5;
            // 
            // pkayit_tc
            // 
            this.pkayit_tc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.pkayit_tc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_tc.Location = new System.Drawing.Point(90, 96);
            this.pkayit_tc.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.pkayit_tc.MaxLength = 11;
            this.pkayit_tc.Multiline = true;
            this.pkayit_tc.Name = "pkayit_tc";
            this.pkayit_tc.Size = new System.Drawing.Size(117, 22);
            this.pkayit_tc.TabIndex = 3;
            this.pkayit_tc.TextChanged += new System.EventHandler(this.pkayit_tc_TextChanged);
            this.pkayit_tc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pkayit_tc_KeyPress);
            // 
            // pkayit_soyad
            // 
            this.pkayit_soyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_soyad.Location = new System.Drawing.Point(89, 64);
            this.pkayit_soyad.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.pkayit_soyad.MaxLength = 30;
            this.pkayit_soyad.Multiline = true;
            this.pkayit_soyad.Name = "pkayit_soyad";
            this.pkayit_soyad.Size = new System.Drawing.Size(117, 22);
            this.pkayit_soyad.TabIndex = 2;
            this.pkayit_soyad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pkayit_soyad_KeyPress);
            // 
            // pkayit_ad
            // 
            this.pkayit_ad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pkayit_ad.Location = new System.Drawing.Point(90, 32);
            this.pkayit_ad.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.pkayit_ad.MaxLength = 30;
            this.pkayit_ad.Name = "pkayit_ad";
            this.pkayit_ad.Size = new System.Drawing.Size(117, 22);
            this.pkayit_ad.TabIndex = 1;
            this.pkayit_ad.TextChanged += new System.EventHandler(this.pkayit_ad_TextChanged);
            this.pkayit_ad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pkayit_ad_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(6, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ad";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frm_personelkayit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(624, 363);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_personelkayit";
            this.Text = "Personel Kayıt";
            this.Load += new System.EventHandler(this.frm_personelkayit_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox pkayit_tel;
        private System.Windows.Forms.ComboBox pkayit_cinsiyet;
        private System.Windows.Forms.TextBox pkayit_tc;
        private System.Windows.Forms.TextBox pkayit_soyad;
        private System.Windows.Forms.TextBox pkayit_ad;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox pkayit_mail;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox pkayit_sifret;
        private System.Windows.Forms.TextBox pkayit_sifre;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox pkayit_maas;
        private System.Windows.Forms.DateTimePicker pkayit_dogum;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RichTextBox pkayit_adres;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnkapat;
        private System.Windows.Forms.Button btnkücült;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button button5;
    }
}