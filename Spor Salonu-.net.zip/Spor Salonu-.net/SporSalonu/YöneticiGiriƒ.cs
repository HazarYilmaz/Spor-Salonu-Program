﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class patrongiris : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        public patrongiris()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void btnkapat_Click(object sender, EventArgs e)
        {

            //if (e.CloseReason == CloseReason.UserClosing)
            //{
            //    DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
            //    if (result == DialogResult.Yes)
            //    {
            //        Environment.Exit(0);
            //    }
            //    else
            //    {
            //        e.Cancel = true;
            //    }
            //}
            //else
            //{
            //    e.Cancel = true;
            //}
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }

        }


        private void textBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_MouseLeave(object sender, EventArgs e)
        {

        }

        private void textBox2_MouseLeave(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pgiris_tc_Enter(object sender, EventArgs e)
        {

        }

        private void pgiris_tc_TextChanged(object sender, EventArgs e)
        {

        }

        private void pgiris_tc_Enter_1(object sender, EventArgs e)
        {
            if (ygiris_kadi.Text == "Kullanıcı Adı")
            {
                ygiris_kadi.Text = "";
                ygiris_kadi.ForeColor = Color.White;

            }
        }

        private void pgiris_sifre_Enter(object sender, EventArgs e)
        {
            if (ygiris_sifre.Text == "Parola")
            {
                ygiris_sifre.Text = "";
                ygiris_sifre.ForeColor = Color.White;
                ygiris_sifre.UseSystemPasswordChar = true;
            }
        }

        private void pgiris_tc_MouseLeave(object sender, EventArgs e)
        {
            //if (pgiris_tc.Text=="")
            //{
            //    pgiris_tc.Text = "TC Kimlik";
            //    pgiris_tc.ForeColor = Color.White;
            //}
        }

        private void pgiris_sifre_MouseLeave(object sender, EventArgs e)
        {
            //if (pgiris_sifre.Text=="")
            //{
            //    pgiris_sifre.Text = "Parola";
            //    pgiris_sifre.ForeColor = Color.LightGray;
            //    pgiris_sifre.UseSystemPasswordChar = false;
            //}
        }

        private void pgiris_tc_Leave(object sender, EventArgs e)
        {
            if (ygiris_kadi.Text == "")
            {
                ygiris_kadi.Text = "TC Kimlik";
                ygiris_kadi.ForeColor = Color.White;
            }
        }

        private void pgiris_sifre_Leave(object sender, EventArgs e)
        {
            if (ygiris_sifre.Text == "")
            {
                ygiris_sifre.Text = "Parola";
                ygiris_sifre.ForeColor = Color.LightGray;
                ygiris_sifre.UseSystemPasswordChar = false;
            }
        }

        private void pgiris_tc_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void pgiris_tc_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button1_Click(object sender, EventArgs e)
        {




            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from yoneticikayit where kullanıcıadi='" + ygiris_kadi.Text + "'and parola ='" + ygiris_sifre.Text + "'", baglanti);
            SqlDataReader dr = komut.ExecuteReader();

            if (dr.Read())
            {
                frm_menu menu = new frm_menu();
                menu.Show();
            }
            else
            {
                MessageBox.Show("Kullanıcı adınız veya şifreniz yanlış");
            }
            baglanti.Close();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            frm_personelkayit kayit = new frm_personelkayit();
            kayit.Show();
        }

        private void pgiris_Load(object sender, EventArgs e)
        {

        }

        private void btnkapat_Click_1(object sender, EventArgs e)
        {
            this.Close();
            frm_menu gosterr = new frm_menu();
            gosterr.Show();
        }

        private void patrongiris_Load(object sender, EventArgs e)
        {
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button4, "İletişim");
        }

        private void pgiris_tc_Enter_2(object sender, EventArgs e)
        {
            if (ygiris_kadi.Text == "Kullanıcı Adı")
            {
                ygiris_kadi.Text = "";
                ygiris_kadi.ForeColor = Color.White;

            }
        }

        private void pgiris_sifre_Enter_1(object sender, EventArgs e)
        {
            if (ygiris_sifre.Text == "Parola")
            {
                ygiris_sifre.Text = "";
                ygiris_sifre.ForeColor = Color.White;
                ygiris_sifre.UseSystemPasswordChar = true;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
             

            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from yoneticikayit where kullanıcıadi='" + ygiris_kadi.Text + "'and parola='" + ygiris_sifre.Text + "'", baglanti);
            SqlDataReader oku=komut.ExecuteReader(); 
               
            if (oku.Read())
            {
                Yönetici menu = new Yönetici();
                menu.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Kullanıcı adınız veya şifreniz yanlış");
                ygiris_kadi.Clear();
                ygiris_sifre.Clear();
                
                if (ygiris_kadi.Text == "")
                {
                    ygiris_kadi.Text = "Kullanıcı Adı";
                    ygiris_kadi.ForeColor = Color.White;
                }
                if (ygiris_sifre.Text == "")
                {
                    ygiris_sifre.Text = "Parola";
                    ygiris_sifre.ForeColor = Color.LightGray;
                    ygiris_sifre.UseSystemPasswordChar = false;
                }

            }
            baglanti.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            frmyonetici_sifre goster2 = new frmyonetici_sifre();
            goster2.Show();
        }

        private void ygiris_kadi_Leave(object sender, EventArgs e)
        {
            if (ygiris_kadi.Text == "")
            {
                ygiris_kadi.Text = "Kullanıcı Adı";
                ygiris_kadi.ForeColor = Color.White;
            }
        }

        private void ygiris_sifre_Leave(object sender, EventArgs e)
        {
            if (ygiris_sifre.Text == "")
            {
                ygiris_sifre.Text = "Parola";
                ygiris_sifre.ForeColor = Color.LightGray;
                ygiris_sifre.UseSystemPasswordChar = false;
            }
        }
    }
}

