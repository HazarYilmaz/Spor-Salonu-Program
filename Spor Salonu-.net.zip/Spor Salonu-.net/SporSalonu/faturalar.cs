﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace SporSalonu
{
    public partial class faturalar : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        public faturalar()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void timer1_Tick(object sender, EventArgs e)
        {
            label11.Text = DateTime.Now.ToShortTimeString();
        }
        private void grid_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select faturaid As [İD], faturaadi As [Gider Adı], tutar As [Tutar],faturatürü [Fatura Türü] from faturalar", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void combo_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select faturaid from faturalar", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            //adap.Fill(dt);

        }

        private void faturalar_Load(object sender, EventArgs e)
        {
            grid_doldur();
            timer1.Interval = 1000;
            timer1.Enabled = true;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button4.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button6.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button1.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button3.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel3.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel4.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            dataGridView1.BackgroundColor = Color.DarkGray;
           
            pictureBox2.Visible = true;
            label2.Visible = true;
            pictureBox3.Visible = false;
            label3.Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            

            this.BackColor = System.Drawing.Color.DarkSlateGray;
            button4.BackColor = System.Drawing.Color.DarkSlateGray;
            button6.BackColor = System.Drawing.Color.DarkSlateGray;
            button1.BackColor = System.Drawing.Color.DarkSlateGray;
            button3.BackColor = System.Drawing.Color.DarkSlateGray;

            panel3.BackColor = Color.SeaGreen;
            panel4.BackColor = Color.SeaGreen;
            dataGridView1.BackgroundColor = Color.Silver;
            pictureBox2.Visible = false;
            label2.Visible = false;
            pictureBox3.Visible = true;
            label3.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textsil.Text = "Fatura ıd";
            btnsil.Visible = true;
            textsil.Visible = true;
            btnara.Visible = false;
            textara.Visible = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textara.Text= "Fatura türü";
            btnara.Visible = true;
            textara.Visible = true;
            btnsil.Visible =false;
            textsil.Visible = false;
        }

        private void textsil_Enter(object sender, EventArgs e)
        {
            if (textsil.Text == "Fatura ıd")
            {
                textsil.Text = "";


            }
        }

        private void textara_Enter(object sender, EventArgs e)
        {
            if (textara.Text == "Fatura türü")
            {
                textara.Text = "";


            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Yönetici gosterrr = new Yönetici();
            gosterrr.Show();
            this.Hide();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            grid_doldur();
            //textBox2.Text = "TC Kimlik numarası";

            SqlCommand kmt = new SqlCommand("Select * from faturalar where faturaid='" + textsil.Text + "'", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                if (MessageBox.Show("Silmek İstediğinden Emin misin? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    MessageBox.Show("Gider Başarıyla Silindi.", "Tebrikler", MessageBoxButtons.OK);

                    baglanti.Open();
                    SqlCommand kmt2 = new SqlCommand("Delete from faturalar where faturaid='" + textsil.Text + "'", baglanti);
                    kmt2.ExecuteNonQuery();
                    baglanti.Close();
                    
                    grid_doldur();
                    combo_doldur();
                    textsil.Clear();
                    textsil.Focus();
                }


            }
            else
            {
                MessageBox.Show("Gider silinememiştir.");
            }
        }

        private void btnara_Click(object sender, EventArgs e)
        {
            grid_doldur();
            //textBox1.Text = "İsim veya Tc Kimlik";

            string aranan = textara.Text.Trim().ToUpper();
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewCell cell in dataGridView1.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            if (cell.Value.ToString().ToUpper() == aranan)
                            {
                                cell.Style.BackColor = Color.DarkTurquoise;
                                textara.Clear();
                                textara.Focus();

                                break;

                            }
                        }
                    }
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label12_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            grid_doldur();
            textsil.Visible = false;
            btnara.Visible = false;
            textara.Visible = false;
            btnsil.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            giderekle goster1 = new giderekle();
            goster1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void textsil_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
