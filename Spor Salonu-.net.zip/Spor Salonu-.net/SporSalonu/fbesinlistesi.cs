﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//www.gorselprogramlama.com
using System.Runtime.InteropServices;

namespace SporSalonu
{
    public partial class fbesinlistesi : Form
    {
        ComboBox f1cbesin;
        ListBox f1porsmiktari, f1kalorimiktari;

        public fbesinlistesi(ComboBox cb, ListBox lb1, ListBox lb2)
        {
            InitializeComponent();

            f1cbesin = cb;
            f1porsmiktari = lb1;
            f1kalorimiktari = lb2;

            for (int i = 0; i < cb.Items.Count; i++)
            {
                lbesin.Items.Add(f1cbesin.Items[i]);
                lpormik.Items.Add(f1porsmiktari.Items[i]);
                lkalori.Items.Add(f1kalorimiktari.Items[i]);

            }

        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void bekle_Click(object sender, EventArgs e)
        {
            int pormik, kalori;
            bool k1 = Int32.TryParse(tpormik.Text, out pormik);
            bool k2 = Int32.TryParse(tkalori.Text, out kalori);

            if (k1 && k2 && tbesin.Text.Length > 0)
            {
                lbesin.Items.Add(tbesin.Text);
                lpormik.Items.Add(pormik);
                lkalori.Items.Add(kalori);

                f1cbesin.Items.Add(tbesin.Text);
                f1porsmiktari.Items.Add(pormik);
                f1kalorimiktari.Items.Add(kalori);

                tbesin.Clear();
                tpormik.Clear();
                tkalori.Clear();
            }

        }

        private void bduzenle_Click(object sender, EventArgs e)
        {
            int secilen = lbesin.SelectedIndex;

            int pormik, kalori;
            bool k1 = Int32.TryParse(tpormik.Text, out pormik);
            bool k2 = Int32.TryParse(tkalori.Text, out kalori);

            if (secilen > -1 && k1 && k2)
            {
                lpormik.Items[secilen] = pormik;//www.gorselprogramlama.com
                lkalori.Items[secilen] = kalori;

                f1porsmiktari.Items[secilen] = pormik;
                f1kalorimiktari.Items[secilen] = kalori;

                tpormik.Clear();
                tkalori.Clear();
            }


        }

        private void bdyaz_Click(object sender, EventArgs e)
        {
            string yazilacak = "";
            for (int i = 0; i < lbesin.Items.Count; i++)
                yazilacak += lbesin.Items[i] + ";" + lpormik.Items[i] + ";" + lkalori.Items[i] + "\n";
            try
            {
                File.WriteAllText("besinliste.txt", yazilacak);
            }
            catch { }

        }

        private void fbesinlistesi_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Enabled = true;
        }

        private void bekle_Click_1(object sender, EventArgs e)
        {
            int pormik, kalori;
            bool k1 = Int32.TryParse(tpormik.Text, out pormik);
            bool k2 = Int32.TryParse(tkalori.Text, out kalori);

            if (k1 && k2 && tbesin.Text.Length > 0)
            {
                lbesin.Items.Add(tbesin.Text);
                lpormik.Items.Add(pormik);
                lkalori.Items.Add(kalori);

                f1cbesin.Items.Add(tbesin.Text);
                f1porsmiktari.Items.Add(pormik);
                f1kalorimiktari.Items.Add(kalori);

                tbesin.Clear();
                tpormik.Clear();
                tkalori.Clear();
            }
        }

        private void bduzenle_Click_1(object sender, EventArgs e)
        {
            int secilen = lbesin.SelectedIndex;

            int pormik, kalori;
            bool k1 = Int32.TryParse(tpormik.Text, out pormik);
            bool k2 = Int32.TryParse(tkalori.Text, out kalori);

            if (secilen > -1 && k1 && k2)
            {
                lpormik.Items[secilen] = pormik;//www.gorselprogramlama.com
                lkalori.Items[secilen] = kalori;

                f1porsmiktari.Items[secilen] = pormik;
                f1kalorimiktari.Items[secilen] = kalori;

                tpormik.Clear();
                tkalori.Clear();
            }
        }

        private void bdyaz_Click_1(object sender, EventArgs e)
        {
            string yazilacak = "";
            for (int i = 0; i < lbesin.Items.Count; i++)
                yazilacak += lbesin.Items[i] + ";" + lpormik.Items[i] + ";" + lkalori.Items[i] + "\n";
            try
            {
                File.WriteAllText("besinliste.txt", yazilacak);
            }
            catch { }
        }

        private void bdoku_Click_1(object sender, EventArgs e)
        {
            lbesin.Items.Clear();
            lpormik.Items.Clear();
            lkalori.Items.Clear();

            f1cbesin.Items.Clear();
            f1kalorimiktari.Items.Clear();
            f1porsmiktari.Items.Clear();

            try
            {
                string[] liste = File.ReadAllLines("besinliste.txt");
                string[] ayrac = { ";" };

                for (int i = 0; i < liste.Length; i++)
                {
                    string[] sutun = liste[i].Split(ayrac, StringSplitOptions.None);
                    if (sutun.Length == 3)
                    {
                        int pormik, kalori;
                        bool k1 = Int32.TryParse(sutun[1], out pormik);
                        bool k2 = Int32.TryParse(sutun[2], out kalori);

                        if (k1 && k2 && sutun[0].Length > 0)
                        {
                            lbesin.Items.Add(sutun[0]);
                            lpormik.Items.Add(pormik);
                            lkalori.Items.Add(kalori);

                            f1cbesin.Items.Add(sutun[0]);
                            f1porsmiktari.Items.Add(pormik);
                            f1kalorimiktari.Items.Add(kalori);
                        }
                    }
                }


            }
            catch { }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            pictureBox2.Visible = true;
            label8.Visible = false;
            pictureBox3.Visible = false;
            label10.Visible = true;
        }

        private void label10_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            pictureBox2.Visible = false;
            label8.Visible = true;
            pictureBox3.Visible = true;
            label10.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Diyet goster = new Diyet();
            goster.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
           
                this.Hide();


           
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label13_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label12.Text = DateTime.Now.ToShortTimeString();
        }

        private void bdoku_Click(object sender, EventArgs e)
        {
            lbesin.Items.Clear();
            lpormik.Items.Clear();
            lkalori.Items.Clear();

            f1cbesin.Items.Clear();
            f1kalorimiktari.Items.Clear();
            f1porsmiktari.Items.Clear();

            try
            {
                string[] liste = File.ReadAllLines("besinliste.txt");
                string[] ayrac = { ";" };

                for (int i = 0; i < liste.Length; i++)
                {
                    string[] sutun = liste[i].Split(ayrac, StringSplitOptions.None);
                    if (sutun.Length == 3)
                    {
                        int pormik, kalori;
                        bool k1 = Int32.TryParse(sutun[1], out pormik);
                        bool k2 = Int32.TryParse(sutun[2], out kalori);

                        if (k1 && k2 && sutun[0].Length > 0)
                        {
                            lbesin.Items.Add(sutun[0]);
                            lpormik.Items.Add(pormik);
                            lkalori.Items.Add(kalori);

                            f1cbesin.Items.Add(sutun[0]);
                            f1porsmiktari.Items.Add(pormik);
                            f1kalorimiktari.Items.Add(kalori);
                        }
                    }
                }


            }
            catch { }

        }//www.gorselprogramlama.com
    }
}
