﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace SporSalonu
{
    public partial class Market : Form
    {
        public Market()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        SqlCommand komut = new SqlCommand();
        public SqlCommand kmt = new SqlCommand();
        public SqlDataAdapter adap = new SqlDataAdapter();
        public DataTable dt = new DataTable();
        public DataTable dt_kategori = new DataTable();
        public DataTable dt_marka = new DataTable();
        public SqlDataReader dr;
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void Market_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Enabled = true;
            komut.CommandText = "SELECT *FROM Urun";
            komut.Connection = baglanti;
            komut.CommandType = CommandType.Text;

            SqlDataReader dr;
            baglanti.Open();
            dr = komut.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["urunad"]);
            }
            baglanti.Close();
        }
       
       

        private void label2_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            pictureBox2.Visible = false;
            label2.Visible = false;
            pictureBox3.Visible = true;
            label3.Visible = true;

            
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            pictureBox2.Visible = true;
            label2.Visible = true;
            pictureBox3.Visible = false;
            label3.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            patrongiris goster = new patrongiris();
            goster.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortTimeString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frm_menu goster3 = new frm_menu();
            goster3.Show();
            this.Hide();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {

                baglanti.Open();



                komut = new SqlCommand("insert into Satis(satisurun,satisadet,satisfiyat) values(@satisurun,@satisadet,@satisfiyat)");

                komut.CommandType = CommandType.Text;

                komut.Parameters.AddWithValue("@satisurun", Convert.ToInt32(textBox1.Text));
                komut.Parameters.AddWithValue("@satisadet", Convert.ToInt32(textBox3.Text));
                komut.Parameters.AddWithValue("@satisfiyat", Convert.ToInt32(textBox2.Text));
               
                



                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("başarıyla satış yapıldı", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();







              
                textBox3.Clear();
                textBox2.Clear();






            }
            catch (Exception)
            {

                MessageBox.Show("Kayıt yapılamıyor");






              
                textBox3.Clear();
            
                textBox2.Clear();

                baglanti.Close();
                throw;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            depo goster31 = new depo();
            goster31.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand veri11 = new SqlCommand("SELECT * FROM  Urun where urunad ='"+comboBox1.Text+"'", baglanti);
            SqlDataAdapter adp = new SqlDataAdapter(veri11);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;
            textBox1.Text = dataGridView1.Rows[0].Cells[0].Value.ToString();
            baglanti.Close();

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
