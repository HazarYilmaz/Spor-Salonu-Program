﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class frmyonetici_kayit : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        SqlCommand komut;
        public frmyonetici_kayit()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length < 11)
            {
                errorProvider1.SetError(textBox1, "TC Kimlik No 11 karakter olmalıdır!");
            }
            else
            {
                errorProvider1.Clear();
            }

            if (textBox1.TextLength == 11)
            {
                int toplam = 0;
                string c, d;
                string sayı1 = textBox1.Text;
                string sayı2 = sayı1[sayı1.Length - 1].ToString();

                foreach (var i in sayı1)
                {
                    c = i.ToString();

                    toplam = toplam + int.Parse(c);
                }

                toplam = toplam - int.Parse(sayı2);

                d = toplam.ToString();

                d = d[d.Length - 1].ToString();

                if (d == sayı2)
                {

                    label6.Text = "";

                    button3.Visible = true;

                }
                else
                {
                    button3.Visible = false;
                    label6.Text = "Girilen Değer Bir Tc Kimlik Numarası Olamaz.";
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            errorProvider1.BlinkRate = 400;
            errorProvider1.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                baglanti.Open();



                komut = new SqlCommand("insert into yoneticikayit(kullanıcıadi,parola,tckimlik,email) values(@kullanıcıadi,@parola,@tckimlik,@email)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@kullanıcıadi", SqlDbType.NVarChar).Value = pkayit_ad.Text;
                komut.Parameters.Add("@parola", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@email", SqlDbType.NVarChar).Value = textBox2.Text;
                


                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();


                
                
                
                
                
                pkayit_ad.Clear();
                textBox3.Clear();
                textBox1.Clear();
                textBox2.Clear();






            }
            catch (Exception)
            {

                MessageBox.Show("böyle kayıt zaten var");

                
                
                
                
             
                pkayit_ad.Clear();
                textBox3.Clear();
                textBox1.Clear();
                textBox2.Clear();

                baglanti.Close();
                throw;
            }
        }

        private void frmyonetici_kayit_Load(object sender, EventArgs e)
        {
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button4, "İletişim");
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            yöneticiler göster = new yöneticiler ();
            göster.Show();
            this.Hide();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
