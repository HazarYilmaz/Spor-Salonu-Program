﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class frm_menu : Form
    {
        public frm_menu()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortTimeString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Üyeler ugoster = new Üyeler();
            ugoster.Show();
            this.Hide();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void frm_menu_Load(object sender, EventArgs e)
        {
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button7, "İletişim");


            timer1.Interval = 1000;
            timer1.Enabled = true;
            timer2.Enabled = true;
            

           


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.DarkOliveGreen;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btn_patron_Click(object sender, EventArgs e)
        {
            patrongiris goster = new patrongiris();
            goster.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            patrongiris goster = new patrongiris();
            goster.Show();
            this.Hide();
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            patrongiris goster = new patrongiris();
            goster.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            olcumler goster55 = new olcumler();
                goster55.Show();
            this.Hide();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Market goster58 = new Market();
            goster58.Show();
            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            button1.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button3.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button5.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button6.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button8.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            pictureBox2.Visible = true;
            label12.Visible = true;
            pictureBox3.Visible = false; 
            label11.Visible = false;



        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            button1.BackColor = System.Drawing.Color.DarkSlateGray;
            button3.BackColor = System.Drawing.Color.DarkSlateGray;
            button5.BackColor = System.Drawing.Color.DarkSlateGray;
            button6.BackColor = System.Drawing.Color.DarkSlateGray;
            button8.BackColor = System.Drawing.Color.DarkSlateGray;
            pictureBox2.Visible = false;
            label12.Visible = false;
            pictureBox3.Visible = true;
            label11.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Diyet göster = new Diyet();
            göster.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            antprogram goster = new antprogram();
            goster.Show();
            this.Hide();
        }
    }
}
