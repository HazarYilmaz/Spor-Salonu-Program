﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class giderekle : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        SqlCommand komut;
        ErrorProvider provider = new ErrorProvider();
        public giderekle()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            faturalar goster = new faturalar();
            goster.Show();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Diğer")
            {
                textBox2.Visible = true;
                comboBox1.Visible = false;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                 && !char.IsSeparator(e.KeyChar);
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Giderin Adını Yazın")
            {
                textBox2.Clear();
            }

        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Giderin Adını Yazın";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Diğer")
            {
                if (textBox1.Text == "" || textBox2.Text == "")
                {

                    MessageBox.Show("Boş Alan bırakılamaz");

                }
                else
                {
                    baglanti.Open();
                    komut = new SqlCommand("insert into faturalar(faturaadi,tutar,faturatürü) values(@faturaadi,@tutar,@faturatürü)");





                    komut.CommandType = CommandType.Text;
                    komut.Parameters.Add("@faturaadi", SqlDbType.NVarChar).Value = comboBox1.Text;
                    komut.Parameters.Add("@tutar", SqlDbType.NVarChar).Value = textBox1.Text;
                    komut.Parameters.Add("@faturatürü", SqlDbType.NVarChar).Value = textBox2.Text;
                    komut.Connection = baglanti;
                    komut.ExecuteNonQuery();


                    DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                    baglanti.Close();

                    comboBox1.Text = ("");
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox2.Visible = false;
                    comboBox1.Visible = true;
                    
                }
            }
            else if(textBox1.Text=="")
            {
                MessageBox.Show("Boş Alan bırakılamaz");
            }
            else
            {
                baglanti.Open();
                komut = new SqlCommand("insert into faturalar(faturaadi,tutar,faturatürü) values(@faturaadi,@tutar,@faturatürü)");





                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@faturaadi", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tutar", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@faturatürü", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                comboBox1.Text = ("");
                textBox1.Clear();
                textBox2.Clear();
                textBox2.Visible = false;
                comboBox1.Visible = true;

            }
            


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void giderekle_Load(object sender, EventArgs e)
        {
           
        }
    }
}
