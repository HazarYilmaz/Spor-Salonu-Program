﻿namespace SporSalonu
{
    partial class fbesinlistesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fbesinlistesi));
            this.bdoku = new System.Windows.Forms.Button();
            this.bdyaz = new System.Windows.Forms.Button();
            this.bduzenle = new System.Windows.Forms.Button();
            this.tkalori = new System.Windows.Forms.TextBox();
            this.tpormik = new System.Windows.Forms.TextBox();
            this.tbesin = new System.Windows.Forms.TextBox();
            this.bekle = new System.Windows.Forms.Button();
            this.lkalori = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lpormik = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbesin = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.btnkapat = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnkücült = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bdoku
            // 
            this.bdoku.BackColor = System.Drawing.Color.Gainsboro;
            this.bdoku.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bdoku.Location = new System.Drawing.Point(341, 426);
            this.bdoku.Name = "bdoku";
            this.bdoku.Size = new System.Drawing.Size(105, 40);
            this.bdoku.TabIndex = 44;
            this.bdoku.Text = "Dosyadan Oku";
            this.bdoku.UseVisualStyleBackColor = false;
            this.bdoku.Click += new System.EventHandler(this.bdoku_Click_1);
            // 
            // bdyaz
            // 
            this.bdyaz.BackColor = System.Drawing.Color.Gainsboro;
            this.bdyaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bdyaz.Location = new System.Drawing.Point(213, 426);
            this.bdyaz.Name = "bdyaz";
            this.bdyaz.Size = new System.Drawing.Size(105, 40);
            this.bdyaz.TabIndex = 43;
            this.bdyaz.Text = "Dosyaya Yaz";
            this.bdyaz.UseVisualStyleBackColor = false;
            this.bdyaz.Click += new System.EventHandler(this.bdyaz_Click_1);
            // 
            // bduzenle
            // 
            this.bduzenle.BackColor = System.Drawing.Color.Gainsboro;
            this.bduzenle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bduzenle.Location = new System.Drawing.Point(341, 380);
            this.bduzenle.Name = "bduzenle";
            this.bduzenle.Size = new System.Drawing.Size(105, 40);
            this.bduzenle.TabIndex = 42;
            this.bduzenle.Text = "Düzenle";
            this.bduzenle.UseVisualStyleBackColor = false;
            this.bduzenle.Click += new System.EventHandler(this.bduzenle_Click_1);
            // 
            // tkalori
            // 
            this.tkalori.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tkalori.Location = new System.Drawing.Point(458, 341);
            this.tkalori.Name = "tkalori";
            this.tkalori.Size = new System.Drawing.Size(58, 24);
            this.tkalori.TabIndex = 41;
            // 
            // tpormik
            // 
            this.tpormik.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tpormik.Location = new System.Drawing.Point(287, 341);
            this.tpormik.Name = "tpormik";
            this.tpormik.Size = new System.Drawing.Size(58, 24);
            this.tpormik.TabIndex = 40;
            // 
            // tbesin
            // 
            this.tbesin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbesin.Location = new System.Drawing.Point(131, 341);
            this.tbesin.Name = "tbesin";
            this.tbesin.Size = new System.Drawing.Size(105, 24);
            this.tbesin.TabIndex = 39;
            // 
            // bekle
            // 
            this.bekle.BackColor = System.Drawing.Color.Gainsboro;
            this.bekle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bekle.Location = new System.Drawing.Point(213, 380);
            this.bekle.Name = "bekle";
            this.bekle.Size = new System.Drawing.Size(105, 40);
            this.bekle.TabIndex = 38;
            this.bekle.Text = "Ekle";
            this.bekle.UseVisualStyleBackColor = false;
            this.bekle.Click += new System.EventHandler(this.bekle_Click_1);
            // 
            // lkalori
            // 
            this.lkalori.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lkalori.FormattingEnabled = true;
            this.lkalori.ItemHeight = 18;
            this.lkalori.Location = new System.Drawing.Point(458, 136);
            this.lkalori.Name = "lkalori";
            this.lkalori.Size = new System.Drawing.Size(146, 202);
            this.lkalori.TabIndex = 37;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(464, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 18);
            this.label5.TabIndex = 36;
            this.label5.Text = "Kalori";
            // 
            // lpormik
            // 
            this.lpormik.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lpormik.FormattingEnabled = true;
            this.lpormik.ItemHeight = 18;
            this.lpormik.Location = new System.Drawing.Point(289, 136);
            this.lpormik.Name = "lpormik";
            this.lpormik.Size = new System.Drawing.Size(139, 202);
            this.lpormik.TabIndex = 35;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(286, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 18);
            this.label7.TabIndex = 34;
            this.label7.Text = "Pors. Mik.";
            // 
            // lbesin
            // 
            this.lbesin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbesin.FormattingEnabled = true;
            this.lbesin.ItemHeight = 18;
            this.lbesin.Location = new System.Drawing.Point(131, 136);
            this.lbesin.Name = "lbesin";
            this.lbesin.Size = new System.Drawing.Size(132, 202);
            this.lbesin.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(148, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 18);
            this.label1.TabIndex = 32;
            this.label1.Text = "Besin";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(0, 55);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(60, 433);
            this.panel2.TabIndex = 49;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SporSalonu.Properties.Resources.icons8_moon_symbol_25;
            this.pictureBox3.Location = new System.Drawing.Point(0, 68);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 26);
            this.pictureBox3.TabIndex = 48;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(27, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 47;
            this.label8.Text = "Koyu";
            this.label8.Visible = false;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(27, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 13);
            this.label10.TabIndex = 46;
            this.label10.Text = "Açık";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SporSalonu.Properties.Resources.icons8_light_25__1_;
            this.pictureBox2.Location = new System.Drawing.Point(0, 68);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(26, 26);
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.btnkapat);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.btnkücült);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(654, 55);
            this.panel1.TabIndex = 48;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // button7
            // 
            this.button7.Cursor = System.Windows.Forms.Cursors.Help;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(572, 0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(32, 40);
            this.button7.TabIndex = 44;
            this.button7.Text = "?";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnkapat
            // 
            this.btnkapat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnkapat.FlatAppearance.BorderSize = 0;
            this.btnkapat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkapat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnkapat.ForeColor = System.Drawing.Color.White;
            this.btnkapat.Location = new System.Drawing.Point(624, 0);
            this.btnkapat.Name = "btnkapat";
            this.btnkapat.Size = new System.Drawing.Size(32, 40);
            this.btnkapat.TabIndex = 42;
            this.btnkapat.Text = "X";
            this.btnkapat.UseVisualStyleBackColor = true;
            this.btnkapat.Click += new System.EventHandler(this.btnkapat_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(39, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 16);
            this.label12.TabIndex = 22;
            this.label12.Text = "saat";
            // 
            // btnkücült
            // 
            this.btnkücült.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnkücült.FlatAppearance.BorderSize = 0;
            this.btnkücült.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkücült.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnkücült.ForeColor = System.Drawing.Color.White;
            this.btnkücült.Location = new System.Drawing.Point(599, 0);
            this.btnkücült.Name = "btnkücült";
            this.btnkücült.Size = new System.Drawing.Size(32, 40);
            this.btnkücült.TabIndex = 43;
            this.btnkücült.Text = "_";
            this.btnkücült.UseVisualStyleBackColor = true;
            this.btnkücült.Click += new System.EventHandler(this.btnkücült_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(255, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(134, 25);
            this.label13.TabIndex = 26;
            this.label13.Text = "Besin Listesi";
            this.label13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label13_MouseDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::SporSalonu.Properties.Resources.icons8_clock_filled_24;
            this.pictureBox1.Location = new System.Drawing.Point(9, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // fbesinlistesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ClientSize = new System.Drawing.Size(654, 488);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bdoku);
            this.Controls.Add(this.bdyaz);
            this.Controls.Add(this.bduzenle);
            this.Controls.Add(this.tkalori);
            this.Controls.Add(this.tpormik);
            this.Controls.Add(this.tbesin);
            this.Controls.Add(this.bekle);
            this.Controls.Add(this.lkalori);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lpormik);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbesin);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "fbesinlistesi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Besin Listesi";
            this.Load += new System.EventHandler(this.fbesinlistesi_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bdoku;
        private System.Windows.Forms.Button bdyaz;
        private System.Windows.Forms.Button bduzenle;
        private System.Windows.Forms.TextBox tkalori;
        private System.Windows.Forms.TextBox tpormik;
        private System.Windows.Forms.TextBox tbesin;
        private System.Windows.Forms.Button bekle;
        private System.Windows.Forms.ListBox lkalori;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lpormik;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox lbesin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnkapat;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnkücült;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
    }
}