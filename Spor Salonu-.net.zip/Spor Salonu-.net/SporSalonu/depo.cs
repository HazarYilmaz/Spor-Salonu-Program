﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class depo : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        public SqlCommand kmt = new SqlCommand();
        public SqlDataAdapter adap = new SqlDataAdapter();
        public DataTable dt = new DataTable();
        public DataTable dt_kategori = new DataTable();
        public DataTable dt_marka = new DataTable();
        public SqlDataReader dr;
       
        
        DataSet ds;
        SqlCommandBuilder cmdb;


        public depo()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void depo_Load(object sender, EventArgs e)
        {
            grid_doldur();




            

        }
        private void combo_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select urunid from Urun", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            //adap.Fill(dt);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Market goster3 = new Market();
            goster3.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            pictureBox2.Visible = true;
            label2.Visible = true;
            pictureBox3.Visible = false;
            label3.Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            pictureBox2.Visible = false;
            label2.Visible = false;
            pictureBox3.Visible = true;
            label3.Visible = true;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void grid_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select urunid As [Ürün İD], urunad As [ürün Adı], urunfiyat As [Ürün Fiyatı],urunadet As[Ürün Miktarı] from Urun", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            grid_doldur();
            textBox1.Visible = false;
            button6.Visible = false;
            textBox2.Visible = false;
            button8.Visible = false;
            textBox4.Visible = false;
            textBox6.Visible = false;
            button9.Visible = false;
            textBox7.Visible = false;

            textBox3.Visible = false;
            textBox5.Visible = false;
            button11.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Text = "Ürün İd";
            textBox1.Visible = false;
            button6.Visible = false;
            textBox2.Visible = true;
            button8.Visible = true;
            textBox4.Visible = false;
            textBox6.Visible = false;
            button9.Visible = false;
            textBox7.Visible = false;

            textBox3.Visible = false;
            textBox5.Visible = false;
            button11.Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Ürün İd veya adı")
            {
                textBox1.Text = "";


            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Ürün İd")
            {
                textBox2.Text = "";


            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Ürün İd veya adı";
            textBox1.Visible = true;
            button6.Visible = true;
            textBox2.Visible = false;
            button8.Visible = false;
            textBox4.Visible = false;
            textBox6.Visible = false;
            button9.Visible = false;
            textBox7.Visible = false;

            textBox3.Visible = false;
            textBox5.Visible = false;
            button11.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            textBox7.Text = "Ürün Fiyatı";
            textBox4.Visible = false;
            textBox6.Visible = false;
            button9.Visible = false;
            textBox3.Visible = true;
            textBox5.Visible = true;
            textBox7.Visible = true;
            button11.Visible = true;
            textBox1.Visible = false;
            button6.Visible = false;
            textBox2.Visible = false;
            button8.Visible = false;
           

        }

        private void button6_Click(object sender, EventArgs e)
        {
            grid_doldur();
            //textBox1.Text = "İsim veya Tc Kimlik";

            string aranan = textBox1.Text.Trim().ToUpper();
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewCell cell in dataGridView1.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            if (cell.Value.ToString().ToUpper() == aranan)
                            {
                                cell.Style.BackColor = Color.DarkTurquoise;
                                textBox1.Clear();
                                textBox1.Focus();

                                break;

                            }
                        }
                    }
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {

            
            
            grid_doldur();

            SqlCommand kmt = new SqlCommand("Select * from Urun where urunid='" + textBox2.Text + "'", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                if (MessageBox.Show("Silmek İstediğinden Emin misin? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    MessageBox.Show("Kayıt Başarıyla Silindi.", "Tebrikler", MessageBoxButtons.OK);

                    baglanti.Open();
                    SqlCommand kmt2 = new SqlCommand("Delete from Urun where urunid='" + textBox2.Text + "'", baglanti);
                    kmt2.ExecuteNonQuery();
                    baglanti.Close();
                    textBox2.Clear();
                    grid_doldur();
                    combo_doldur();
                }


            }
            
            else
            {
                MessageBox.Show("Kayıt silinememiştir.");
            }
            }
            catch (Exception)
            {
                MessageBox.Show("Kayıt silinememiştir.");
                throw;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
           
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            


            
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button1.Focus();
            textBox3.Visible = true;
            textBox5.Visible = true;
            button11.Visible = true;
            textBox1.Visible = false;
            button6.Visible = false;
            textBox2.Visible = false;
            button8.Visible = false;
            
          
        }

        private void button11_Click(object sender, EventArgs e)
        {
            kmt = new SqlCommand(" select count(*) from Urun where urunad=@urunad", baglanti);
            baglanti.Open();

            kmt.Parameters.AddWithValue("@urunad", Convert.ToString(textBox3.Text));
            
         
            int sonuc = (int)kmt.ExecuteScalar();
            if (sonuc == 0)
            {





                kmt = new SqlCommand("insert into Urun(urunad,urunadet,urunfiyat) values(@urunad,@urunadet,@urunfiyat)");

                kmt.CommandType = CommandType.Text;
                kmt.Parameters.Add("@urunad", SqlDbType.NVarChar).Value = textBox3.Text;
                kmt.Parameters.Add("@urunadet", SqlDbType.Int).Value = textBox5.Text;
                kmt.Parameters.AddWithValue("@urunfiyat", Convert.ToInt32(textBox7.Text));
                





                kmt.Connection = baglanti;
                kmt.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();
                textBox3.Text = "Ürün Adı";
                textBox5.Text = "Ürün Adeti";
                grid_doldur();



                baglanti.Close();


            }
            else
            {
                MessageBox.Show("Bu ürün zaten kayıtlı");
                textBox3.Text = "Ürün Adı";
                textBox5.Text = "Ürün Adeti";

                baglanti.Close();

            }
        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_Enter_1(object sender, EventArgs e)
        {
            if (textBox3.Text == "Ürün Adı")
            {
                textBox3.Text = "";


            }
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            if (textBox5.Text == "Ürün Adeti")
            {
                textBox5.Text = "";


            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text=="")
            {
                textBox1.Text = "Ürün İd veya adı";
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Ürün İd ";
            }
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "Ürün Adı";
            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "Ürün Adeti";
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
                    }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
           
            

            

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            if (baglanti.State == ConnectionState.Closed || baglanti.State == ConnectionState.Broken)

                baglanti.Open();
            try
            {


                SqlCommand kmt = new SqlCommand("update Urun set urunadet=@urunadet where urunid='" + textBox4.Text + "'", baglanti);
                kmt.CommandType = CommandType.Text;
                kmt.Parameters.Add("@urunadet", SqlDbType.BigInt).Value = textBox6.Text;
                
               
                kmt.ExecuteNonQuery();
                grid_doldur();
                MessageBox.Show("Kayıt Güncellendi");
            }
            catch (Exception)
            {
                MessageBox.Show("Güncelleme Başarısız!");
                throw;
            }
            grid_doldur();
            baglanti.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            textBox4.Visible = true;
            textBox6.Visible = true;
            button9.Visible = true;
            textBox3.Visible = false;
            textBox5.Visible = false;
            button11.Visible = false;
            textBox1.Visible = false;
            textBox7.Visible = false;
            button6.Visible = false;
            textBox2.Visible = false;
            button8.Visible = false;
            if (textBox6.Text == "")
            {
                textBox6.Text = "Adet Miktarı";


            }
            if (textBox4.Text == "")
            {
                textBox4.Text = "Ürün İd";


            }
        }

        private void textBox4_Enter_1(object sender, EventArgs e)
        {
            if (textBox4.Text == "Ürün İd")
            {
                textBox4.Text = "";


            }
        }

        private void textBox6_Enter(object sender, EventArgs e)
        {
            if (textBox6.Text == "Adet Miktarı")
            {
                textBox6.Text = "";


            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void textBox5_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox2_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox4_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox7_Enter(object sender, EventArgs e)
        {
            if (textBox7.Text=="Ürün Fiyatı")
            {
                textBox7.Text = "";
            }
        }

        private void textBox7_Leave(object sender, EventArgs e)
        {
            if (textBox7.Text=="")
            {
                textBox7.Text = "Ürün Fiyatı";
            }
        }
    }
}
