﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace SporSalonu
{
    public partial class Personeller : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        

        
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        public Personeller()
        {
            InitializeComponent();
        }


        private void btn_personelgoster_Click(object sender, EventArgs e)
        {
            grid_doldur();
            textBox1.Visible = false;
            button4.Visible = false;
            textBox2.Visible = false;
            button5.Visible = false;
            
        }

        private void frm_personelgoster_Load(object sender, EventArgs e)
        {
          
            timer1.Interval = 1000;
            timer1.Enabled = true;
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button7, "İletişim");
            Aciklama.SetToolTip(button3, "Geri");
          
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortTimeString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            button4.Visible = false;
            textBox2.Visible = false;
            button5.Visible = false;
            frm_personelkayit goster1 = new frm_personelkayit();
            goster1.Show();
            this.Close();
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "İsim veya Tc Kimlik";
            grid_doldur();
            textBox1.Visible =true;
            button5.Visible = true;
            textBox2.Visible = false;
            button4.Visible = false;
        }

        private void btn_psil_Click(object sender, EventArgs e)
        {
            textBox2.Text = "TC Kimlik numarası";
            textBox2.Visible = true;
            button4.Visible = true;
            textBox1.Visible = false;
            button5.Visible = false;
            grid_doldur();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Yönetici gosterrr = new Yönetici();
            gosterrr.Show();
            this.Hide();
        }
        private void combo_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select tckimlik from personelkayit", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            //adap.Fill(dt);

        }
        private void grid_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select personelid As [Personel İD], ad As [Ad], soyad As [Soyad], tckimlik As [Tc Kimlik numarası],telefon As[Telefon], email As[Email], maas As[Maaş], cinsiyet As[Cinsiyeti],adres As[Adres],dogumtarihi As[Doğumtarihi] from personelkayit", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            
            grid_doldur();
            SqlCommand kmt = new SqlCommand("Select * from personelkayit where tckimlik='" + textBox2.Text + "'", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                baglanti.Open();
                SqlCommand kmt2 = new SqlCommand("Delete from personelkayit where tckimlik='" + textBox2.Text + "'", baglanti);
                kmt2.ExecuteNonQuery();
                baglanti.Close();
                grid_doldur();
                combo_doldur();
                MessageBox.Show("Kayıt başarıyla silindi");
            }
            else
            {
                MessageBox.Show("Kayıt silinememiştir.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
            grid_doldur();
            string aranan = textBox1.Text.Trim().ToUpper();
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewCell cell in dataGridView1.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            if (cell.Value.ToString().ToUpper() == aranan)
                            {
                                cell.Style.BackColor = Color.DarkTurquoise;
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "TC Kimlik numarası")
            {
                textBox2.Text = "";


            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "İsim veya Tc Kimlik")
            {
                textBox1.Text = "";


            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster = new İletişim();
            goster.Show();
            this.Hide();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label12_Click(object sender, EventArgs e)
        {

            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            button1.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            btn_psil.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button2.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            btn_personelgoster.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            label12.Visible = false;
            pictureBox3.Visible = false;
            label13.Visible = true;
            pictureBox2.Visible = true;
        }

        private void label13_Click(object sender, EventArgs e)
        {

            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            button1.BackColor = System.Drawing.Color.DarkSlateGray;
            btn_psil.BackColor = System.Drawing.Color.DarkSlateGray;
            button2.BackColor = System.Drawing.Color.DarkSlateGray;
            btn_personelgoster.BackColor = System.Drawing.Color.DarkSlateGray;
            label12.Visible = true;
            pictureBox3.Visible = true;
            label13.Visible = false;
            pictureBox2.Visible = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
