﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using System.Media;

namespace SporSalonu
{
    public partial class pgiris : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        public pgiris()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void btnkapat_Click(object sender, EventArgs e)
        {

            //if (e.CloseReason == CloseReason.UserClosing)
            //{
            //    DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
            //    if (result == DialogResult.Yes)
            //    {
            //        Environment.Exit(0);
            //    }
            //    else
            //    {
            //        e.Cancel = true;
            //    }
            //}
            //else
            //{
            //    e.Cancel = true;
            //}
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                 MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                 System.Windows.Forms.Application.Exit();
                
                
            }
            
            {
                this.Activate();
            }

        }


        private void textBox1_Enter(object sender, EventArgs e)
        {
           
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_MouseLeave(object sender, EventArgs e)
        {

        }

        private void textBox2_MouseLeave(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pgiris_tc_Enter(object sender, EventArgs e)
        {

        }

        private void pgiris_tc_TextChanged(object sender, EventArgs e)
        {

        }

        private void pgiris_tc_Enter_1(object sender, EventArgs e)
        {
            if (pgiris_tc.Text=="TC Kimlik")
            {
                pgiris_tc.Text = "";
                pgiris_tc.ForeColor = Color.White;

            }
        }

        private void pgiris_sifre_Enter(object sender, EventArgs e)
        {
            if (pgiris_sifre.Text=="Parola")
            {
                pgiris_sifre.Text = "";
                pgiris_sifre.ForeColor = Color.White;
                pgiris_sifre.UseSystemPasswordChar = true;
            }
        }

        private void pgiris_tc_MouseLeave(object sender, EventArgs e)
        {
            //if (pgiris_tc.Text=="")
            //{
            //    pgiris_tc.Text = "TC Kimlik";
            //    pgiris_tc.ForeColor = Color.White;
            //}
        }

        private void pgiris_sifre_MouseLeave(object sender, EventArgs e)
        {
            //if (pgiris_sifre.Text=="")
            //{
            //    pgiris_sifre.Text = "Parola";
            //    pgiris_sifre.ForeColor = Color.LightGray;
            //    pgiris_sifre.UseSystemPasswordChar = false;
            //}
        }

        private void pgiris_tc_Leave(object sender, EventArgs e)
        {
            if (pgiris_tc.Text == "")
            {
                pgiris_tc.Text = "TC Kimlik";
                pgiris_tc.ForeColor = Color.White;
            }
        }

        private void pgiris_sifre_Leave(object sender, EventArgs e)
        {
            if (pgiris_sifre.Text == "")
            {
                pgiris_sifre.Text = "Parola";
                pgiris_sifre.ForeColor = Color.LightGray;
                pgiris_sifre.UseSystemPasswordChar = false;
            }
        }

        private void pgiris_tc_TextChanged_1(object sender, EventArgs e)
        {
            if (pgiris_tc.Text.Length < 11)
            {
                errorProvider1.SetError(pgiris_tc, "TC Kimlik No 11 karakter olmalıdır!");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void pgiris_tc_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
           



            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from personelkayit where tckimlik='" + pgiris_tc.Text + "'and sifre ='" + pgiris_sifre.Text + "'", baglanti);
            SqlDataReader dr = komut.ExecuteReader();

            if (dr.Read())
            {
                SoundPlayer ses = new SoundPlayer();
                string dizin = Application.StartupPath + "\\translate_tts.wav";
                ses.SoundLocation = dizin;
                ses.Play();
                frm_menu gosteer = new frm_menu();
                gosteer.Show();
               // ses.Stop();
                this.Hide();
            }
            else
            {
                
                MessageBox.Show("Kullanıcı adınız veya şifreniz yanlış");
               
               
                pgiris_tc.Clear();
                pgiris_sifre.Clear();
                if (pgiris_tc.Text == "")
                {
                    pgiris_tc.Text = "TC Kimlik";
                    pgiris_tc.ForeColor = Color.White;
                }
                if (pgiris_sifre.Text == "")
                {
                    pgiris_sifre.Text = "Parola";
                    pgiris_sifre.ForeColor = Color.LightGray;
                    pgiris_sifre.UseSystemPasswordChar = false;
                }
               
            }
            baglanti.Close();
           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //frm_personelkayit kayit = new frm_personelkayit();
            //kayit.Show();
            frm_sifre sifre = new frm_sifre();
            sifre.Show();
            this.Hide();
        }

        private void pgiris_Load(object sender, EventArgs e)
        {
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            timer1.Interval = 1000;
            timer1.Enabled = true;
            errorProvider1.BlinkRate = 400;
            errorProvider1.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;
            pgiris_tc.MaxLength = 11;
            errorProvider2.BlinkRate = 400;
            errorProvider2.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;
            pgiris_sifre.MaxLength = 11;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToShortTimeString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToShortTimeString();
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pgiris_sifre_TextChanged(object sender, EventArgs e)
        {
            errorProvider2.BlinkRate = 400;
            errorProvider2.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;
            pgiris_sifre.MaxLength = 50;

        }
    }
}

