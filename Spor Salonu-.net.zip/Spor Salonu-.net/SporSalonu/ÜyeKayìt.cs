﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class frm_üyeekle : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        SqlCommand komut;
        SqlDataReader oku;
        public frm_üyeekle()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void pkayit_adres_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void pkayit_ad_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            errorProvider1.BlinkRate = 400;
            errorProvider1.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void pkayit_ad_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                 && !char.IsSeparator(e.KeyChar);
        }

        private void pkayit_soyad_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)
                 && !char.IsSeparator(e.KeyChar);
        }

        private void pkayit_tc_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void pkayit_tc_TextChanged(object sender, EventArgs e)
        {
            if (pkayit_tc.Text.Length < 11)
            {
                errorProvider1.SetError(pkayit_tc, "TC Kimlik No 11 karakter olmalıdır!");
            }
            else
            {
                errorProvider1.Clear();
            }

            if (pkayit_tc.TextLength == 11)
            {
                int toplam = 0;
                string c, d;
                string sayı1 = pkayit_tc.Text;
                string sayı2 = sayı1[sayı1.Length - 1].ToString();

                foreach (var i in sayı1)
                {
                    c = i.ToString();

                    toplam = toplam + int.Parse(c);
                }

                toplam = toplam - int.Parse(sayı2);

                d = toplam.ToString();

                d = d[d.Length - 1].ToString();

                if (d == sayı2)
                {

                    label24.Text = "";

                    button3.Visible = true;

                }
                else
                {
                    button3.Visible = false;
                    label24.Text = "Girilen Değer Bir Tc Kimlik Numarası Olamaz.";
                }
            }
        }

        private void pkayit_cinsiyet_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pkayit_tel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from uyekayit where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(pkayit_tc.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into uyekayit(ad,soyad,tckimlik,telefon,cinsiyet,email,uyeliksuresi,ucret,dogumtarihi,uyeliktarihi,adres) values(@ad,@soyad,@tckimlik,@telefon,@cinsiyet,@email,@uyeliksuresi,@ucret,@dogumtarihi,@uyeliktarihi,@adres)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@ad", SqlDbType.NVarChar).Value = pkayit_ad.Text;
                komut.Parameters.Add("@soyad", SqlDbType.NVarChar).Value = pkayit_soyad.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = pkayit_tc.Text;
                komut.Parameters.Add("@telefon", SqlDbType.NVarChar).Value = pkayit_tel.Text;
                komut.Parameters.Add("@cinsiyet", SqlDbType.NVarChar).Value = pkayit_cinsiyet.Text;
                komut.Parameters.Add("@email", SqlDbType.NVarChar).Value = pkayit_mail.Text;
                komut.Parameters.Add("@uyeliksuresi", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@ucret", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@dogumtarihi", SqlDbType.Date).Value = dateTimePicker1.Value;
                komut.Parameters.Add("@uyeliktarihi", SqlDbType.Date).Value = dateTimePicker2.Value;
                komut.Parameters.Add("@adres", SqlDbType.NVarChar).Value = pkayit_adres.Text;

               



                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                pkayit_tc.Clear();
                textBox1.Clear();
                textBox2.Clear();
                dateTimePicker2.Value = DateTime.Now;
                dateTimePicker1.Value = DateTime.Now;
                pkayit_ad.Clear();
                pkayit_adres.Clear();
                pkayit_cinsiyet.Text = "";
                pkayit_soyad.Clear();
                pkayit_tel.Clear();
                pkayit_mail.Clear();
                baglanti.Close();


            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış");

                pkayit_tc.Clear();
                textBox1.Clear();
                textBox2.Clear();
                dateTimePicker2.Value = DateTime.Now;
                dateTimePicker1.Value = DateTime.Now;
                pkayit_ad.Clear();
                pkayit_adres.Clear();
                pkayit_mail.Clear();
                pkayit_cinsiyet.Text = "";
                pkayit_soyad.Clear();
                pkayit_tel.Clear();
                baglanti.Close();

            }
        }

        private void frm_üyeekle_Load(object sender, EventArgs e)
        {
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button4, "İletişim");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Üyeler goster = new Üyeler();
            goster.Show();
            this.Hide();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
