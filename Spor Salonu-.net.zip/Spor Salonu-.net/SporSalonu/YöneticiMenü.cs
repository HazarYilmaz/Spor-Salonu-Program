﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class Yönetici : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        public Yönetici()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void btn_fatura_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_personel_Click(object sender, EventArgs e)
        {
            Personeller goster = new Personeller();
            goster.Show();
        }

        private void frm_patron_Load(object sender, EventArgs e)
        {
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(button3, "Ana Menü");
            timer1.Interval = 1000;
            timer1.Enabled = true;
           
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button7, "İletişim");
            Aciklama.SetToolTip(button3, "Geri");
            DataSet ds2 = new DataSet();
            SqlDataAdapter da2 = new SqlDataAdapter("SELECT * From personelkayit", baglanti);
            ds2.Clear();
            da2.Fill(ds2, "personelkayit");
            label9.Text = ds2.Tables["personelkayit"].Rows.Count.ToString();

            DataSet ds3 = new DataSet();
            SqlDataAdapter da3 = new SqlDataAdapter("SELECT * From uyekayit", baglanti);
            ds3.Clear();
            da3.Fill(ds3, "uyekayit");
            label10.Text = ds3.Tables["uyekayit"].Rows.Count.ToString();
            baglanti.Close();


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortTimeString();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Personeller goster = new Personeller();
            goster.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frm_menu goster1 = new frm_menu();
            goster1.Show();
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            maas goster31 = new maas();
            goster31.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            faturalar goster5 = new faturalar();
            goster5.Show();
            this.Hide();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            button1.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button3.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button4.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            button5.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            label12.Visible = false;
            pictureBox3.Visible = false;
            pictureBox2.Visible = true;
            label13.Visible = true;
        }

        private void label13_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            button1.BackColor = System.Drawing.Color.DarkSlateGray;
            button3.BackColor = System.Drawing.Color.DarkSlateGray;
            button5.BackColor = System.Drawing.Color.DarkSlateGray;
            button4.BackColor = System.Drawing.Color.DarkSlateGray;

            label12.Visible = true;
            pictureBox3.Visible = true;
            pictureBox2.Visible = false;
            label13.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            frmyonetici_kayit goster93 = new frmyonetici_kayit();
            goster93.Show();
            this.Hide();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            yöneticiler goster5 = new yöneticiler();
            goster5.Show();
            this.Hide();
        }
    }
}
