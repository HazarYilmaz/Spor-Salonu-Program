﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class frm_personel_giris : Form
    {
        public frm_personel_giris()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Data Source = HAZARBABA39;initial catalog = sporsalonu; Integrated Security = True");
        

        private void btn_pkayıt_Click(object sender, EventArgs e)
        {
            frm_personel_kayıt f2 = new frm_personel_kayıt();

            f2.ShowDialog();
        }

        private void btn_pgiris_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("Select * from personelkayit where tckimlik= '" + txt_tc.Text + "' and sifre='" +txt_sifre.Text+"'",baglanti );

            SqlDataReader dr = komut.ExecuteReader();

            if (dr.Read())
            {
                frm_personel_giris formkapa = new frm_personel_giris();
                formkapa.Close();
                fr_menu formmenu = new fr_menu();
                formmenu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kimlik numaranız veya şifreniz yanlış");
            }
            baglanti.Close();
           
            


            
        }

        private void txt_tc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
            if (txt_tc.TextLength == 11)
            {
                e.Handled = true;
            }

        }
    }
}
