﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace SporSalonu
{
    public partial class Frm_uyebilgi : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = HAZARBABA39;initial catalog = sporsalonu; Integrated Security = True");
        public Frm_uyebilgi()
        {
            InitializeComponent();
           
        }
       
       

        private void btn_uyeekle_Click(object sender, EventArgs e)
        {
            frm_uyeekle abc = new frm_uyeekle();
                abc.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            button5.Visible = false;
            frm_uyeekle abc = new frm_uyeekle();
            abc.Show();
        }

        private void Frm_uyebilgi_Load(object sender, EventArgs e)
        {
            


        }
        public void verigoster(string veriler)
        {

            SqlDataAdapter adap = new SqlDataAdapter(veriler, baglanti);
            DataSet ds = new DataSet();
            adap.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

        }
        private void button1_Click(object sender, EventArgs e)
        {
            verigoster("Select * from uyekayit");
            textBox1.Visible = false;
            button5.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Visible = true;
            button5.Visible = true;
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand kmd = new SqlCommand("Select Ad as [Adı], Soyad as [Soyadı], tckimlik as [Tc Kimlik numarası], telefon as [Telefon numarası],cinsiyet as [Cinsiyeti],uyeliksuresi as [Üyelik süresi],dogumtarihi as [Doğum Tarihi],uyeliktarihi as [Üyelik tarihi], boy as [Boyu], kilo as [Kilosu] from uyekayit where ogr_no= '" + textBox1.Text + "' ", baglanti);
                SqlDataAdapter adp = new SqlDataAdapter(kmd);
                DataTable dt_ara = new DataTable();
                adp.Fill(dt_ara);
                dataGridView1.Refresh();
                dataGridView1.DataSource = dt_ara;

                //txt_ara_ogr_no.Text = dataGridView1.Rows[0].Cells[0].Value.ToString();
                //txt_ara_ad.Text = dataGridView1.Rows[0].Cells[1].Value.ToString();
                //txt_ara_soyad.Text = dataGridView1.Rows[0].Cells[2].Value.ToString();
                //txt_ara_bolum.Text = dataGridView1.Rows[0].Cells[3].Value.ToString();
                //txt_ara_dal.Text = dataGridView1.Rows[0].Cells[4].Value.ToString();

            }
            catch (Exception)
            {
                DialogResult b = MessageBox.Show(textBox1.Text + " NUMARALI KAYIT BULUNMAMAKTADIR", "UYARI !!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //textBox1.Clear();
                //txt_ara_ad.Clear();
                //txt_ara_soyad.Clear();
                //txt_ara_bolum.Clear();
                //txt_ara_dal.Clear();
            }
            finally
            {
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            button5.Visible = false;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            fr_menu goster1 = new fr_menu();
            goster1.Show();
            this.Hide();
        }
    }
}
