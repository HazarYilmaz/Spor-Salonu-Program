﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace SporSalonu
{
    public partial class maas : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        public maas()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void maas_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Enabled = true;

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            string islem = "select sum(maas) as toplam from personelkayit";
            baglanti.Open();
            SqlCommand komut = new SqlCommand(islem, baglanti);
            Label2.Text = komut.ExecuteScalar().ToString();
            komut.ExecuteNonQuery();


            string islem2 = "select AVG(maas) as toplam from personelkayit";
            
            SqlCommand komut2 = new SqlCommand(islem2,baglanti);
            Label4.Text = komut2.ExecuteScalar().ToString();
            komut2.ExecuteNonQuery();



            string islem3 = "select MAX(maas) as toplam from personelkayit";

            SqlCommand komut3 = new SqlCommand(islem3, baglanti);
            Label6.Text = komut3.ExecuteScalar().ToString();
            komut3.ExecuteNonQuery();


            string islem4 = "select MIN(maas) as toplam from personelkayit";

            SqlCommand komut4 = new SqlCommand(islem4, baglanti);
            Label8.Text = komut4.ExecuteScalar().ToString();
            komut4.ExecuteNonQuery();

            string islem5 = "select sum(tutar) as toplam from faturalar";

            SqlCommand komut5 = new SqlCommand(islem5, baglanti);
            label21.Text = komut5.ExecuteScalar().ToString();
            komut5.ExecuteNonQuery();

           


            DataSet ds2 = new DataSet();
            SqlDataAdapter da2 = new SqlDataAdapter("SELECT * From personelkayit", baglanti);
            ds2.Clear();
            da2.Fill(ds2, "personelkayit");
            label25.Text = ds2.Tables["personelkayit"].Rows.Count.ToString();

            int sayi2 = Convert.ToInt16(label21.Text);

            int sayi1 = Convert.ToInt16(Label2.Text);

            label29.Text = Convert.ToString(sayi2 + sayi1);
            

            

            label18.Text = Convert.ToString((sayi1+sayi2) * 12);




            baglanti.Close();








        }

        private void button5_Click(object sender, EventArgs e)
        {
            Yönetici goster = new Yönetici();
            goster.Show();
            this.Hide();
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label12_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void Label2_Click(object sender, EventArgs e)
        {
            




        }

        private void button1_Click(object sender, EventArgs e)
        {
            string islem = "select sum(ucret) as toplam from uyekayit";
            baglanti.Open();
            SqlCommand komut = new SqlCommand(islem, baglanti);
            label27.Text = komut.ExecuteScalar().ToString();
            komut.ExecuteNonQuery();

            string islem98 = "select sum(satisfiyat) as toplam from Satis";

            SqlCommand komut98 = new SqlCommand(islem98, baglanti);
            label36.Text = komut98.ExecuteScalar().ToString();
            komut98.ExecuteNonQuery();

            
            DataSet ds3 = new DataSet();
            SqlDataAdapter da3 = new SqlDataAdapter("SELECT * From uyekayit",baglanti);
            ds3.Clear();
            da3.Fill(ds3, "uyekayit");
            label13.Text = ds3.Tables["uyekayit"].Rows.Count.ToString();

           
            int sayi5 = Convert.ToInt16(label36.Text);
            int sayi2 = Convert.ToInt16(label27.Text);
            int sayi3 = (sayi2 + sayi5);
            label31.Text = Convert.ToString(sayi3);
            label16.Text = Convert.ToString(sayi3 * 12);






            baglanti.Close();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string islem = "select sum(ucret) as toplam from uyekayit";
            baglanti.Open();
            SqlCommand komut = new SqlCommand(islem, baglanti);
            label27.Text = komut.ExecuteScalar().ToString();
            komut.ExecuteNonQuery();


            DataSet ds3 = new DataSet();
            SqlDataAdapter da3 = new SqlDataAdapter("SELECT * From uyekayit", baglanti);
            ds3.Clear();
            da3.Fill(ds3, "uyekayit");
            label13.Text = ds3.Tables["uyekayit"].Rows.Count.ToString();



           

            

            string islem5 = "select sum(maas) as toplam from personelkayit";
            
            SqlCommand komut5 = new SqlCommand(islem5, baglanti);
            Label2.Text = komut5.ExecuteScalar().ToString();
            komut.ExecuteNonQuery();

            string islem98 = "select sum(satisfiyat) as toplam from Satis";

            SqlCommand komut98 = new SqlCommand(islem98, baglanti);
            label36.Text = komut98.ExecuteScalar().ToString();
            komut98.ExecuteNonQuery();

            string islem2 = "select AVG(maas) as toplam from personelkayit";

            SqlCommand komut2 = new SqlCommand(islem2, baglanti);
            Label4.Text = komut2.ExecuteScalar().ToString();
            komut2.ExecuteNonQuery();

            string islem7 = "select sum(tutar) as toplam from faturalar";

            SqlCommand komut7 = new SqlCommand(islem7, baglanti);
            label21.Text = komut7.ExecuteScalar().ToString();
            komut7.ExecuteNonQuery();


            string islem3 = "select MAX(maas) as toplam from personelkayit";

            SqlCommand komut3 = new SqlCommand(islem3, baglanti);
            Label6.Text = komut3.ExecuteScalar().ToString();
            komut3.ExecuteNonQuery();


            string islem4 = "select MIN(maas) as toplam from personelkayit";

            SqlCommand komut4 = new SqlCommand(islem4, baglanti);
            Label8.Text = komut4.ExecuteScalar().ToString();
            komut4.ExecuteNonQuery();


            DataSet ds2 = new DataSet();
            SqlDataAdapter da2 = new SqlDataAdapter("SELECT * From personelkayit", baglanti);
            ds2.Clear();
            da2.Fill(ds2, "personelkayit");
            label25.Text = ds2.Tables["personelkayit"].Rows.Count.ToString();

            //aylık gider toplamı
            int sayi1 = Convert.ToInt32(Label2.Text);
            int sayi2 = Convert.ToInt32(label21.Text);
            int aylikgidertoplam = Convert.ToInt32(sayi1 + sayi2);
            label29.Text = Convert.ToString(aylikgidertoplam);
            

            //--------------------------------------------------------------------
            //Aylık kazanç toplamı
            int sayi3 = Convert.ToInt32(label36.Text);
            int sayi4 = Convert.ToInt32(label27.Text);
            int aylikkazanctoplam = Convert.ToInt32(sayi3 + sayi4);
            label31.Text = Convert.ToString(aylikkazanctoplam);
            //--------------------------------------------------------------------
            //aylık cari hesabı
            int aylıkcari = Convert.ToInt32(aylikkazanctoplam - aylikgidertoplam);
            label33.Text = Convert.ToString(aylıkcari);
            //--------------------------------------------------------------------

            if (aylıkcari >= 0)
                label34.Text = "Cari açık yoktur";
            else
                label34.Text = "Cari açık vardır";
            //--------------------------------------------------------------------
            //yıllık gider toplamı
            int yillikgider = Convert.ToInt32(aylikgidertoplam);
            int yıllıkgidertoplam = Convert.ToInt32(aylikgidertoplam * 12);
            label18.Text = Convert.ToString(yıllıkgidertoplam);
            //---------------------------------------------------------------------
            //yıllık kazanç toplamı
            int yillikkazanç = Convert.ToInt32(aylikkazanctoplam);
            int yillikkazançtoplam = Convert.ToInt32(aylikkazanctoplam*12);
            label16.Text = Convert.ToString(yillikkazançtoplam);
            //---------------------------------------------------------------------
            //yıllık cari hesabı
            int yillikcari = Convert.ToInt32(yillikkazançtoplam-yıllıkgidertoplam);
            label23.Text = Convert.ToString(yillikcari);
            //----------------------------------------------------------------------
            if (yillikcari >= 0)
            label20.Text = "Cari Açık Yoktur";
            else
            label20.Text = "Cari Açık Vardır";

            baglanti.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label11.Text = DateTime.Now.ToShortTimeString();
        }

        private void GroupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label36_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label37_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);
            panel3.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            label37.Visible = false;
            pictureBox3.Visible = false;
            label38.Visible = true;
            pictureBox2.Visible = true;

        }

        private void label38_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel3.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            label37.Visible = true;
            pictureBox3.Visible = true;
            label38.Visible = false;
            pictureBox2.Visible = false;
        }
    }
}
