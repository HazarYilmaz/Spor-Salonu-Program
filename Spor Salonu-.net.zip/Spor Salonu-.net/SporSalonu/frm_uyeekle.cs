﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class frm_uyeekle : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = HAZARBABA39;initial catalog = sporsalonu; Integrated Security = True");
        SqlDataReader oku;
        SqlCommand komut;
        public frm_uyeekle()
        {
            InitializeComponent();
        }

        private void personel_kayit_Click(object sender, EventArgs e)
        {

            komut = new SqlCommand("insert into uyekayit(Ad,soyad,tckimlik,telefon,email,cinsiyet,uyeliksuresi,ucret,dogumtarihi,uyeliktarihi,boy,kilo) values(@ad,@soyad,@tckimlik,@telefon,@email,@cinsiyet,@üyeliksüresi,@ücret,@dogumtarihi,@uyeliktarihi,@boy,@kilo)");
            baglanti.Open();
            komut.CommandType = new CommandType();

            komut.Parameters.Add("@ad", SqlDbType.NVarChar).Value=ukayit_ad.Text;
            komut.Parameters.Add("@soyad", SqlDbType.NVarChar).Value = ukayit_soyad.Text;
            komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = ukayit_tc.Text;
            komut.Parameters.Add("@telefon", SqlDbType.NVarChar).Value = ukayit_tel.Text;
            komut.Parameters.Add("@email", SqlDbType.NVarChar).Value = ukayit_mail.Text;
            komut.Parameters.Add("@cinsiyet", SqlDbType.NVarChar).Value = ukayit_cinsiyet.Text;
            komut.Parameters.Add("@üyeliksüresi", SqlDbType.NVarChar).Value = ukayit_uyeliksure.Text;
            komut.Parameters.Add("@ücret", SqlDbType.NVarChar).Value = ukayit_ucret.Text;
            komut.Parameters.Add("@dogumtarihi", SqlDbType.NVarChar).Value = ukayit_dogum.Value;
            komut.Parameters.Add("@uyeliktarihi", SqlDbType.NVarChar).Value = ukayit_uyetarih.Value;
            komut.Parameters.Add("@boy", SqlDbType.Int).Value = ukayit_boy.Text;
            komut.Parameters.Add("@kilo", SqlDbType.Int).Value = ukayit_kilo.Text;

            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
            
            baglanti.Close();

            
            this.Close();






        }

        private void pkayit_mail_TextChanged(object sender, EventArgs e)
        {

        }

        private void frm_uyeekle_Load(object sender, EventArgs e)
        {

        }
    }
}
