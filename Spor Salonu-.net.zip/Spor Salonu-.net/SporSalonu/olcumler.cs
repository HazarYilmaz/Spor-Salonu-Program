﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace SporSalonu
{
    public partial class olcumler : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        public olcumler()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void label11_Click(object sender, EventArgs e)
        {

            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            dataGridView1.BackgroundColor = Color.DarkGray;
            label11.Visible = false;
            pictureBox3.Visible = false;
            label12.Visible = true;
            pictureBox4.Visible = true;
        }
        private void combo_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select tckimlik from olcumler", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            //adap.Fill(dt);

        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;
            dataGridView1.BackgroundColor = Color.Silver;
            label11.Visible = true;
            pictureBox3.Visible = true;
            label12.Visible = false;
            pictureBox4.Visible = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_menu goster1 = new frm_menu();
            goster1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }
        private void grid_doldur()
        {
            SqlCommand kmt = new SqlCommand("Select olcüid As [Ölçü İD], tckimlik As [TC Kimlik], boyun As [Boyun], omuz As [Omuz],göğüs As[Göğüs], kol As[Kol], bel As[Bel], kalça As[Kalça],bacak As [Bacak],boy As[Boy],kilo As[Kilo] from olcumler", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void olcumler_Load(object sender, EventArgs e)
        {
            grid_doldur();
            ToolTip Aciklama = new ToolTip();
            Aciklama.SetToolTip(btnkapat, "Programı Kapatır");
            Aciklama.SetToolTip(btnkücült, "Programı Küçültür");
            Aciklama.SetToolTip(button6, "İletişim");
            Aciklama.SetToolTip(button10, "Geri");

            timer1.Interval = 1000;
            timer1.Enabled = true;
        }
        

        private void timer1_Tick(object sender, EventArgs e)
        {
            label6.Text = DateTime.Now.ToShortTimeString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text = "TC Kimlik numarası";
            textBox1.Visible = false;
            button5.Visible = false;
            textBox2.Visible = true;
            button8.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "TC Kimlik numarası";
            textBox1.Visible = true;
            button5.Visible = true;
            textBox2.Visible = false;
            button8.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            olcuekle goster9 = new olcuekle();
            goster9.Show();
            this.Hide();
            textBox1.Visible = false;
            button5.Visible = false;
            textBox2.Visible = false;
            button8.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            grid_doldur();
            textBox1.Visible = false;
            button5.Visible = false;
            textBox2.Visible = false;
            button8.Visible = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            grid_doldur();
            //textBox2.Text = "TC Kimlik numarası";

            SqlCommand kmt = new SqlCommand("Select * from olcumler where tckimlik='" + textBox2.Text + "'", baglanti);
            SqlDataAdapter adap = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                if (MessageBox.Show("Silmek İstediğinden Emin misin? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    MessageBox.Show("Kayıt Başarıyla Silindi.", "Tebrikler", MessageBoxButtons.OK);

                    baglanti.Open();
                    SqlCommand kmt2 = new SqlCommand("Delete from olcumler where tckimlik='" + textBox2.Text + "'", baglanti);
                    kmt2.ExecuteNonQuery();
                    baglanti.Close();
                    textBox1.Text = "TC Kimlik numarası";
                    textBox2.Text = "TC Kimlik numarası";
                    grid_doldur();
                    combo_doldur();
                }


            }
            else
            {
                MessageBox.Show("Kayıt silinememiştir.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            grid_doldur();
            //textBox1.Text = "İsim veya Tc Kimlik";

            string aranan = textBox1.Text.Trim().ToUpper();
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    foreach (DataGridViewCell cell in dataGridView1.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            if (cell.Value.ToString().ToUpper() == aranan)
                            {
                                cell.Style.BackColor = Color.DarkTurquoise;
                                textBox1.Clear();
                                textBox1.Focus();

                                break;

                            }
                        }
                    }
                }
            }

        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "TC Kimlik numarası")
            {
                textBox2.Text = "";


            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "TC Kimlik numarası")
            {
                textBox1.Text = "";


            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {

            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {

            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
