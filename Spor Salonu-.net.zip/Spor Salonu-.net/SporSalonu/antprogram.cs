﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace SporSalonu
{
    public partial class antprogram : Form
    {
        public antprogram()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source = LAB1PC4\\SQLEXPRESS;initial catalog = sporsalonu; Integrated Security = True");
        SqlCommand komut = new SqlCommand();
        public SqlCommand kmt = new SqlCommand();
        public SqlDataAdapter adap = new SqlDataAdapter();
        public DataTable dt = new DataTable();
        public DataTable dt_kategori = new DataTable();
        public DataTable dt_marka = new DataTable();
        public SqlDataReader dr;
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void button5_Click(object sender, EventArgs e)
        {
            frm_menu goster = new frm_menu();
            goster.Show();
            this.Hide();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            İletişim goster1 = new İletişim();
            goster1.Show();
        }

        private void btnkücült_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnkapat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Kapatmak istediğinizden emin misiniz? ", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Uygulama başarıyla kapatıldı.", "Uygulama kapandı!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();


            }

            {
                this.Activate();
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(25, 25, 25);

            panel2.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            panel1.BackColor = System.Drawing.Color.FromArgb(40, 40, 40);
            pictureBox2.Visible = true;
            label11.Visible = false;
            pictureBox3.Visible = false;
            label12.Visible = true;
        }

        private void label12_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkSlateGray;

            panel1.BackColor = Color.SeaGreen;
            panel2.BackColor = Color.SeaGreen;

            pictureBox2.Visible = false;
            label12.Visible = false;
            pictureBox3.Visible = true;
            label11.Visible = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortTimeString();
        }

        private void antprogram_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Enabled = true;
            komut.CommandText = "SELECT *FROM uyekayit";
            komut.Connection = baglanti;
            komut.CommandType = CommandType.Text;

            SqlDataReader dr;
            baglanti.Open();
            dr = komut.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["tckimlik"]);
            }
            baglanti.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            label3.Visible = false;
            label2.Visible = false;
            label4.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
            button6.Visible = true;
            button8.Visible = true;
            button9.Visible = true;
            button10.Visible = true;
            button11.Visible = true;
            button12.Visible = true;
            button13.Visible = true;
            button14.Visible = true;
            button20.Visible = true;
            button16.Visible = true;
            button17.Visible = true;
            button18.Visible = true;
            button19.Visible = true;
            button21.Visible = true;


        }

        private void button18_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            comboBox1.Visible = true;
            label6.Visible = true;
            button22.Visible = true;
            button23.Visible = false;
            button24.Visible = false;
            button25.Visible = false;
            button26.Visible = false;
            button27.Visible = false;
            button28.Visible = false;
            button29.Visible = false;
            button30.Visible = false;
            button31.Visible = false;
            button32.Visible = false;
            button33.Visible = false;
            button34.Visible = false;
            button35.Visible = false;
            button36.Visible = false;
            button37.Visible = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            label3.Visible = false;
            label2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            button23.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            button24.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            button25.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            button26.Visible = true;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            button27.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            button28.Visible = true;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            button29.Visible = true;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            button30.Visible = true;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            label44.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            button31.Visible = true;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            comboBox1.Visible = true;
            label6.Visible = true;
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            label44.Visible = true;
            label45.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            textBox15.Visible = true;
            button32.Visible = true;

        }

        private void button20_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            label44.Visible = true;
            label45.Visible = true;
            label46.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            textBox15.Visible = true;
            textBox16.Visible = true;
            button33.Visible = true;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            label44.Visible = true;
            label45.Visible = true;
            label46.Visible = true;
            label47.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            textBox15.Visible = true;
            textBox16.Visible = true;
            textBox17.Visible = true;
            button34.Visible = true;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            button16.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            label44.Visible = true;
            label45.Visible = true;
            label46.Visible = true;
            label47.Visible = true;
            label48.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            textBox15.Visible = true;
            textBox16.Visible = true;
            textBox17.Visible = true;
            textBox18.Visible = true;
            button35.Visible = true;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            button20.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            label44.Visible = true;
            label45.Visible = true;
            label46.Visible = true;
            label47.Visible = true;
            label48.Visible = true;
            label49.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            textBox15.Visible = true;
            textBox16.Visible = true;
            textBox17.Visible = true;
            textBox18.Visible = true;
            textBox19.Visible = true;
            button36.Visible = true;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button6.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            comboBox1.Visible = true;
            label6.Visible = true;
            button20.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            button19.Visible = false;
            button21.Visible = false;
            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
            label35.Visible = true;
            label36.Visible = true;
            label37.Visible = true;
            label38.Visible = true;
            label39.Visible = true;
            label40.Visible = true;
            label41.Visible = true;
            label42.Visible = true;
            label43.Visible = true;
            label44.Visible = true;
            label45.Visible = true;
            label46.Visible = true;
            label47.Visible = true;
            label48.Visible = true;
            label49.Visible = true;
            label50.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            textBox15.Visible = true;
            textBox16.Visible = true;
            textBox17.Visible = true;
            textBox18.Visible = true;
            textBox19.Visible = true;
            textBox20.Visible = true;
            button37.Visible = true;
        }

        private void button27_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                
               









                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button37_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17,h18,h19,h20) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13,@h14,@h15,@h16,@h17,@h18,@h19,@h20)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                komut.Parameters.Add("@h14", SqlDbType.NVarChar).Value = textBox14.Text;
                komut.Parameters.Add("@h15", SqlDbType.NVarChar).Value = textBox15.Text;
                komut.Parameters.Add("@h16", SqlDbType.NVarChar).Value = textBox16.Text;
                komut.Parameters.Add("@h17", SqlDbType.NVarChar).Value = textBox17.Text;
                komut.Parameters.Add("@h18", SqlDbType.NVarChar).Value = textBox18.Text;
                komut.Parameters.Add("@h19", SqlDbType.NVarChar).Value = textBox19.Text;
                komut.Parameters.Add("@h20", SqlDbType.NVarChar).Value = textBox20.Text;




                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button26_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
               
                









                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button25_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                
               









                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button35_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17,h18) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13,@h14,@h15,@h16,@h17,@h18)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                komut.Parameters.Add("@h14", SqlDbType.NVarChar).Value = textBox14.Text;
                komut.Parameters.Add("@h15", SqlDbType.NVarChar).Value = textBox15.Text;
                komut.Parameters.Add("@h16", SqlDbType.NVarChar).Value = textBox16.Text;
                komut.Parameters.Add("@h17", SqlDbType.NVarChar).Value = textBox17.Text;
                komut.Parameters.Add("@h18", SqlDbType.NVarChar).Value = textBox18.Text;
                





                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button24_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                
               









                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button34_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13,@h14,@h15,@h16,@h17)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                komut.Parameters.Add("@h14", SqlDbType.NVarChar).Value = textBox14.Text;
                komut.Parameters.Add("@h15", SqlDbType.NVarChar).Value = textBox15.Text;
                komut.Parameters.Add("@h16", SqlDbType.NVarChar).Value = textBox16.Text;
                komut.Parameters.Add("@h17", SqlDbType.NVarChar).Value = textBox17.Text;
                






                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button23_Click(object sender, EventArgs e)
        {
           

        }

        private void button33_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13,@h14,@h15,@h16)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                komut.Parameters.Add("@h14", SqlDbType.NVarChar).Value = textBox14.Text;
                komut.Parameters.Add("@h15", SqlDbType.NVarChar).Value = textBox15.Text;
                komut.Parameters.Add("@h16", SqlDbType.NVarChar).Value = textBox16.Text;
                







                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }

        }

        private void button22_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
               



                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();
                
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }
            
        }

        private void button32_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13,@h14,@h15)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                komut.Parameters.Add("@h14", SqlDbType.NVarChar).Value = textBox14.Text;
                komut.Parameters.Add("@h15", SqlDbType.NVarChar).Value = textBox15.Text;
                








                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13,@h14)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                komut.Parameters.Add("@h14", SqlDbType.NVarChar).Value = textBox14.Text;
                
                








                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                
                









                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
               
               









                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
               
               









                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand veri11 = new SqlCommand("SELECT * FROM  uyekayit where tckimlik ='" + comboBox1.Text + "'", baglanti);
            SqlDataAdapter adp = new SqlDataAdapter(veri11);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;
            textBox21.Text = dataGridView1.Rows[0].Cells[0].Value.ToString();
            baglanti.Close();
        }

        private void button36_Click(object sender, EventArgs e)
        {
            komut = new SqlCommand(" select count(*) from antp where tckimlik=@tckimlik", baglanti);
            baglanti.Open();

            komut.Parameters.AddWithValue("@tckimlik", Int64.Parse(comboBox1.Text));
            int sonuc = (int)komut.ExecuteScalar();
            if (sonuc == 0)
            {





                komut = new SqlCommand("insert into antp(tckimlik,tur,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15,h16,h17,h18,h19) values(@tckimlik,@tur,@h1,@h2,@h3,@h4,@h5,@h6,@h7,@h8,@h9,@h10,@h11,@h12,@h13,@h14,@h15,@h16,@h17,@h18,@h19)");

                komut.CommandType = CommandType.Text;
                komut.Parameters.Add("@tckimlik", SqlDbType.NVarChar).Value = comboBox1.Text;
                komut.Parameters.Add("@tur", SqlDbType.NVarChar).Value = textBox22.Text;
                komut.Parameters.Add("@h1", SqlDbType.NVarChar).Value = textBox1.Text;
                komut.Parameters.Add("@h2", SqlDbType.NVarChar).Value = textBox2.Text;
                komut.Parameters.Add("@h3", SqlDbType.NVarChar).Value = textBox3.Text;
                komut.Parameters.Add("@h4", SqlDbType.NVarChar).Value = textBox4.Text;
                komut.Parameters.Add("@h5", SqlDbType.NVarChar).Value = textBox5.Text;
                komut.Parameters.Add("@h6", SqlDbType.NVarChar).Value = textBox6.Text;
                komut.Parameters.Add("@h7", SqlDbType.NVarChar).Value = textBox7.Text;
                komut.Parameters.Add("@h8", SqlDbType.NVarChar).Value = textBox8.Text;
                komut.Parameters.Add("@h9", SqlDbType.NVarChar).Value = textBox9.Text;
                komut.Parameters.Add("@h10", SqlDbType.NVarChar).Value = textBox10.Text;
                komut.Parameters.Add("@h11", SqlDbType.NVarChar).Value = textBox11.Text;
                komut.Parameters.Add("@h12", SqlDbType.NVarChar).Value = textBox12.Text;
                komut.Parameters.Add("@h13", SqlDbType.NVarChar).Value = textBox13.Text;
                komut.Parameters.Add("@h14", SqlDbType.NVarChar).Value = textBox14.Text;
                komut.Parameters.Add("@h15", SqlDbType.NVarChar).Value = textBox15.Text;
                komut.Parameters.Add("@h16", SqlDbType.NVarChar).Value = textBox16.Text;
                komut.Parameters.Add("@h17", SqlDbType.NVarChar).Value = textBox17.Text;
                komut.Parameters.Add("@h18", SqlDbType.NVarChar).Value = textBox18.Text;
                komut.Parameters.Add("@h19", SqlDbType.NVarChar).Value = textBox19.Text;
                




                komut.Connection = baglanti;
                komut.ExecuteNonQuery();


                DialogResult a = MessageBox.Show("Yeni Kayıt Oluşturuldu", "Tebrikler", MessageBoxButtons.OK, MessageBoxIcon.None);
                baglanti.Close();

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();



            }
            else
            {
                MessageBox.Show("Tc kimlik numarası daha önce kullanılmış silip tekrar deneyin ");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                baglanti.Close();

            }
        }
    }
}
